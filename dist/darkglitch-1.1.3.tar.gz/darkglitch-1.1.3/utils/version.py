__version__ = "1.1.3"


def version():
    return f"darkglitch v{__version__}"